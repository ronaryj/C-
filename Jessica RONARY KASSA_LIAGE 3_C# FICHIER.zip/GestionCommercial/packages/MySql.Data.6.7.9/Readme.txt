Connector/Net 6.7  Release Notes
------------------------------------

Welcome to the release notes for Connector/Net 6.7

What's new in 6.7
--------------------

- WinRT Connector.
- Load Balancing client support.
- Entity Framework 5 support.
- Memcached client.


Be sure and check the documentation for more information on these new features.