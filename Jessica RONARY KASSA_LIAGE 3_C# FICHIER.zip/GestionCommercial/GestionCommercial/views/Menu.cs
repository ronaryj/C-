﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionCommercial
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            new Commande().Visible=true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login lo=new Login();
            lo.Visible = true;
        }

        private void label13_Click(object sender, EventArgs e)
        {
            new Inscription().Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            new Article().Visible = true;
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            new Commande().Visible = true;
        }
    }
}
