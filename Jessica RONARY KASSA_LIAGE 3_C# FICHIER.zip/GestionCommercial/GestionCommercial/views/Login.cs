﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestionCommercial.services;

namespace GestionCommercial
{
    public partial class Login : Form
    {
        UserService userService = new UserService();
        public Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (userService.findUserByLoginPassword(clogin.Text, cpassword.Text))
            {
                this.Visible = false;
                new Menu().Show();
                return;
            }
            MessageBox.Show("Veuillez vérifier vos identifiants de connexion");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            new Register().Visible = true;
        }
        public void GetFocusRemoveTexLogin(object sender, EventArgs e)
        {
            if (clogin.Text == "Veuillez entrez votre nom d'utilisateur") clogin.Text = "";
        }
        public void LostFocusRemoveTexLogin(object sender, EventArgs e)
        {
            if (clogin.Text == "") clogin.Text = "Veuillez entrez votre nom d'utilisateur";
        }


        public void GetFocusRemoveTexPassword(object sender, EventArgs e)
        {
            if (cpassword.Text == "Veuillez entrez votre mot de passe")
            {
                cpassword.PasswordChar = '*';
                cpassword.Text = "";
            }
        }
        public void LostFocusRemoveTexPassword(object sender, EventArgs e)
        {
            if (cpassword.Text == "")
            {
                cpassword.Text = "Veuillez entrez votre mot de passe";
                cpassword.PasswordChar = ' ';
            }
        }
    }
}
