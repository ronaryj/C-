﻿namespace GestionCommercial
{
    partial class Inscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inscription));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.itlogin = new System.Windows.Forms.TextBox();
            this.itnom = new System.Windows.Forms.TextBox();
            this.itprenom = new System.Windows.Forms.TextBox();
            this.itpassword = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.UserGridList = new System.Windows.Forms.DataGridView();
            this.icprofil = new System.Windows.Forms.ComboBox();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.login = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Profil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserGridList)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(166, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(249, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enregistrement User";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(60, 205);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(56, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(60, 331);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(56, 52);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(60, 394);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(56, 52);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(60, 268);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(56, 52);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // itlogin
            // 
            this.itlogin.Location = new System.Drawing.Point(162, 216);
            this.itlogin.MaximumSize = new System.Drawing.Size(316, 30);
            this.itlogin.MinimumSize = new System.Drawing.Size(316, 30);
            this.itlogin.Multiline = true;
            this.itlogin.Name = "itlogin";
            this.itlogin.Size = new System.Drawing.Size(316, 30);
            this.itlogin.TabIndex = 2;
            this.itlogin.Text = "Entrer le login";
            this.itlogin.WordWrap = false;
            this.itlogin.GotFocus += new System.EventHandler(this.GetFocusRemoveTexLogin);
            this.itlogin.LostFocus += new System.EventHandler(this.LostFocusRemoveTexLogin);
            // 
            // itnom
            // 
            this.itnom.Location = new System.Drawing.Point(162, 342);
            this.itnom.MaximumSize = new System.Drawing.Size(316, 30);
            this.itnom.MinimumSize = new System.Drawing.Size(316, 30);
            this.itnom.Multiline = true;
            this.itnom.Name = "itnom";
            this.itnom.Size = new System.Drawing.Size(316, 30);
            this.itnom.TabIndex = 4;
            this.itnom.Text = "Entrer le nom";
            this.itnom.GotFocus += new System.EventHandler(this.GetFocusRemoveTexNom);
            this.itnom.LostFocus += new System.EventHandler(this.LostFocusRemoveTexNom);
            // 
            // itprenom
            // 
            this.itprenom.Location = new System.Drawing.Point(162, 405);
            this.itprenom.MaximumSize = new System.Drawing.Size(316, 30);
            this.itprenom.MinimumSize = new System.Drawing.Size(316, 30);
            this.itprenom.Multiline = true;
            this.itprenom.Name = "itprenom";
            this.itprenom.Size = new System.Drawing.Size(316, 30);
            this.itprenom.TabIndex = 5;
            this.itprenom.Text = "Entrer le prenom";
            this.itprenom.GotFocus += new System.EventHandler(this.GetFocusRemoveTexPrenom);
            this.itprenom.LostFocus += new System.EventHandler(this.LostFocusRemoveTexPrenom);
            // 
            // itpassword
            // 
            this.itpassword.Location = new System.Drawing.Point(162, 279);
            this.itpassword.MaximumSize = new System.Drawing.Size(316, 30);
            this.itpassword.MinimumSize = new System.Drawing.Size(316, 30);
            this.itpassword.Multiline = true;
            this.itpassword.Name = "itpassword";
            this.itpassword.Size = new System.Drawing.Size(316, 30);
            this.itpassword.TabIndex = 3;
            this.itpassword.Text = "Entrer le mot de passe";
            this.itpassword.GotFocus += new System.EventHandler(this.GetFocusRemoveTexPassword);
            this.itpassword.LostFocus += new System.EventHandler(this.LostFocusRemoveTexPassword);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.button1.Location = new System.Drawing.Point(352, 548);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 35);
            this.button1.TabIndex = 7;
            this.button1.Text = "Enregistrer";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(684, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 29);
            this.label2.TabIndex = 14;
            this.label2.Text = "Liste des users";
            // 
            // UserGridList
            // 
            this.UserGridList.AllowUserToAddRows = false;
            this.UserGridList.AllowUserToDeleteRows = false;
            this.UserGridList.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UserGridList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UserGridList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.nom,
            this.prenom,
            this.login,
            this.Profil});
            this.UserGridList.Location = new System.Drawing.Point(511, 116);
            this.UserGridList.Name = "UserGridList";
            this.UserGridList.ReadOnly = true;
            this.UserGridList.RowTemplate.Height = 28;
            this.UserGridList.Size = new System.Drawing.Size(599, 467);
            this.UserGridList.TabIndex = 1;
            // 
            // icprofil
            // 
            this.icprofil.FormattingEnabled = true;
            this.icprofil.ItemHeight = 20;
            this.icprofil.Items.AddRange(new object[] {
            "Administrateur",
            "Vendeur",
            "Acheteur",
            "Livreur"});
            this.icprofil.Location = new System.Drawing.Point(162, 469);
            this.icprofil.MaximumSize = new System.Drawing.Size(316, 0);
            this.icprofil.MinimumSize = new System.Drawing.Size(316, 0);
            this.icprofil.Name = "icprofil";
            this.icprofil.Size = new System.Drawing.Size(316, 28);
            this.icprofil.TabIndex = 6;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 40;
            // 
            // nom
            // 
            this.nom.HeaderText = "Nom";
            this.nom.Name = "nom";
            this.nom.ReadOnly = true;
            // 
            // prenom
            // 
            this.prenom.HeaderText = "Prenom";
            this.prenom.Name = "prenom";
            this.prenom.ReadOnly = true;
            // 
            // login
            // 
            this.login.HeaderText = "Login";
            this.login.Name = "login";
            this.login.ReadOnly = true;
            // 
            // Profil
            // 
            this.Profil.HeaderText = "Profil";
            this.Profil.Name = "Profil";
            this.Profil.ReadOnly = true;
            // 
            // Inscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1122, 595);
            this.Controls.Add(this.icprofil);
            this.Controls.Add(this.UserGridList);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.itprenom);
            this.Controls.Add(this.itnom);
            this.Controls.Add(this.itpassword);
            this.Controls.Add(this.itlogin);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Inscription";
            this.Text = "Inscription";
            this.Load += new System.EventHandler(this.Inscription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserGridList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox itlogin;
        private System.Windows.Forms.TextBox itnom;
        private System.Windows.Forms.TextBox itprenom;
        private System.Windows.Forms.TextBox itpassword;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView UserGridList;
        private System.Windows.Forms.ComboBox icprofil;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prenom;
        private System.Windows.Forms.DataGridViewTextBoxColumn login;
        private System.Windows.Forms.DataGridViewTextBoxColumn Profil;
    }
}