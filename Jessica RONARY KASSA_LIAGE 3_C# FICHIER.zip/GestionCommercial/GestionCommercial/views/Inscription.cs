﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestionCommercial.services;
using GestionCommercial.modeles;

namespace GestionCommercial
{
    public partial class Inscription : Form
    {
        UserService userService = new UserService();
        public Inscription()
        {
            InitializeComponent();
        }

        private void Inscription_Load(object sender, EventArgs e)
        {
            updateGrid();
        }
        
        void updateGrid()
        {
            while(UserGridList.Rows.Count>0)
            UserGridList.Rows.RemoveAt(0);
            userService.findAllUser().ForEach(u =>
            {
                UserGridList.Rows.Add(u.id, u.nom, u.prenom, u.login, u.profil);
            });
        }


        public void GetFocusRemoveTexNom(object sender, EventArgs e)
        {
            if (itnom.Text == "Entrer le nom") itnom.Text = "";
        }

        public void LostFocusRemoveTexNom(object sender, EventArgs e)
        {
            if (itnom.Text == "") itnom.Text = "Entrer le nom";
        }

        public void GetFocusRemoveTexPrenom(object sender, EventArgs e)
        {
            if (itprenom.Text == "Entrer le prenom") itprenom.Text = "";
        }

        public void LostFocusRemoveTexPrenom(object sender, EventArgs e)
        {
            if (itprenom.Text.Trim() == "") itprenom.Text = "Entrer le prenom";
        }


        public void GetFocusRemoveTexLogin(object sender, EventArgs e)
        {
            if (itlogin.Text.Trim() == "Entrer le login") itlogin.Text = "";
        }
        public void LostFocusRemoveTexLogin(object sender, EventArgs e)
        {
            if (itlogin.Text.Trim() == "") itlogin.Text = "Entrer le login";
        }


        public void GetFocusRemoveTexPassword(object sender, EventArgs e)
        {
            if (itpassword.Text == "Entrer le mot de passe")
            {
                itpassword.PasswordChar = '*';
                itpassword.Text = "";
            }
        }
        public void LostFocusRemoveTexPassword(object sender, EventArgs e)
        {
            if (itpassword.Text.Trim() == "")
            {
                itpassword.Text = "Entrer le mot de passe";
                itpassword.PasswordChar = ' ';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (userService.existUser(itlogin.Text))
            {
                MessageBox.Show("Ce login existe déjà dans la base de données");
                return;
            }
            if (userService.createUser(itnom.Text, itprenom.Text, itlogin.Text, itpassword.Text,icprofil.Text))
            {
                MessageBox.Show("Le compte d'utilisateur a été crée");
                updateGrid();
                return;
            }
            MessageBox.Show("Impossible de créer ce compte");
        }
    }
}
