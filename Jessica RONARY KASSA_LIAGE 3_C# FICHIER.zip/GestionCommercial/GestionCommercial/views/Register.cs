﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using GestionCommercial.services;

namespace GestionCommercial
{
    public partial class Register : Form
    {
        UserService userService;
        public Register()
        {
            InitializeComponent();
            userService = new UserService();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (userService.existUser(login.Text))
            {
                MessageBox.Show("Ce nom d'utilisateur existe déjà dans la base de données");
                return;
            }
            if (userService.createUser(nom.Text, prenom.Text, login.Text, password.Text))
            {
                MessageBox.Show("Votre compte d'utilisateur a été crée, veuillez vous connecter");
                this.Visible = false;
                new Login().Visible = true;
                return;
            }
            MessageBox.Show("Impossible de créer ce utilisateur");
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            new Login().Visible = true;
        }

        public void GetFocusRemoveTexNom(object sender, EventArgs e)
        {
            if (nom.Text == "Veuillez entrez votre nom") nom.Text = "";
        }

        public void LostFocusRemoveTexNom(object sender, EventArgs e)
        {
            if (nom.Text == "")nom.Text= "Veuillez entrez votre nom";
        }

        public void GetFocusRemoveTexPrenom(object sender, EventArgs e)
        {
            if (prenom.Text == "Veuillez entrez votre prenom") prenom.Text = "";
        }

        public void LostFocusRemoveTexPrenom(object sender, EventArgs e)
        {
            if (prenom.Text == "") prenom.Text = "Veuillez entrez votre prenom";
        }


        public void GetFocusRemoveTexLogin(object sender, EventArgs e)
        {
            if (login.Text == "Veuillez entrez votre nom d'utilisateur") login.Text = "";
        }
        public void LostFocusRemoveTexLogin(object sender, EventArgs e)
        {
            if (login.Text=="")login.Text = "Veuillez entrez votre nom d'utilisateur";
        }


        public void GetFocusRemoveTexPassword(object sender, EventArgs e)
        {
            if (password.Text == "Veuillez entrez votre mot de passe")
            {
                password.PasswordChar = '*';
                password.Text = "";
            }
        }
        public void LostFocusRemoveTexPassword(object sender, EventArgs e)
        {
            if (password.Text=="")
            {
                password.Text = "Veuillez entrez votre mot de passe";
                password.PasswordChar =' ';
            }
        }
    }
}
