﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestionCommercial.dao;
using GestionCommercial.modeles;

namespace GestionCommercial.services
{
    class UserService
    {
        UserDao userDao = new UserDao();
        public Boolean createUser(string nom, string prenom, string login, string password)
        {

            return userDao.create(new User(nom, prenom, login, password)) != 0;
        }
        public Boolean createUser(string nom, string prenom, string login, string password,string profil)
        {

            return userDao.create(new User(nom, prenom, login, password,profil)) != 0;
        }
        public Boolean existUser(string login)
        {
            return userDao.findByLogin(login);
        }

        public Boolean findUserByLoginPassword(string login, string password)
        {
            return userDao.findByLoginAndPassword(login, password);
        }

        public List<User> findAllUser()
        {
            return userDao.findAll();
        }
    }
}
