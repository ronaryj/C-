﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionCommercial.modeles
{
    class User
    {
        public int id;
        public string nom;
        public string prenom;
        public string login;
        public string password;
        public string profil;
        public User(string nom, string prenom, string login, string password)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.login = login;
            this.password = password;
        }
        public User(string nom, string prenom, string login, string password,string profil)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.login = login;
            this.password = password;
            this.profil = profil;
        }
        public User() { }

    }
}
