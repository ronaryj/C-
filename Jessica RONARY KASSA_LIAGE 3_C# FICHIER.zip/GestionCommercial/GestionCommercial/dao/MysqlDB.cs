﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MySql.Data.MySqlClient;

namespace GestionCommercial.dao
{

    class MysqlDB
    {
        private String user = "root";
        private String pwd = "";
        private String server = "localhost";
        private String bd = "coursjava";
        private MySqlConnection cnx;
        public void getConnexion()
        {
                //Configuration des paramètres de connexion
                string MyConStr = "Server=localhost;Database=" + bd + ";uid=" + user + ";pwd=" + pwd;
                //Etablir la Connexion
                cnx = new MySqlConnection(MyConStr);
            cnx.Open();
            if(cnx.State == System.Data.ConnectionState.Open)
            {
                
            }
    }


    }
}
