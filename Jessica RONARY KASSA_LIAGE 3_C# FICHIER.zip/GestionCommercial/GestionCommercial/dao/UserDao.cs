﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestionCommercial.modeles;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace GestionCommercial.dao
{
    class UserDao : IDao<User>
    {
        private string user = "root";
        private string pwd = "";
        private string server = "localhost";
        private string bd = "gescom";
        private MySqlConnection conn;
        MysqlDB mysql;
        const string SQL_BY_LOGIN_AND_PASSWORD="Select * From users where login =? AND password=?";
        const string SQL_BY_LOGIN="Select * From users where login =?";
        const string SQL_BY_ID = "Select * From users where id =? ";
        const string SQL_SELECT_ALL_USER = "SELECT `id`, `nom`, `prenom`, `login`, `password`, `profil` FROM `users`";
        const string SQL_INSERT ="INSERT INTO `users`(`id`, `nom`, `prenom`, `login`, `password`) VALUES (NULL,?,?,?,?)";
        public UserDao()
        {
            mysql = new MysqlDB();
        }

        public int create(User user)
        {
            int result = 0;
            string MyConStr = "Server="+server+";Database=" + bd + ";uid=" + this.user + ";pwd=" + pwd;
            //Etablir la Connexion
            try {
                conn = new MySqlConnection(MyConStr);
                conn.Open();
                if (conn.State == System.Data.ConnectionState.Open)
                {

                }
                MySqlCommand cmd = null;
                string cmdString = "INSERT INTO `users`(`id`, `nom`, `prenom`, `login`, `password`,`profil`) VALUES (NULL," + "'" + user.nom + "','" + user.prenom + "','" + user.login + "','" + user.password + "','"+user.profil+"')";
                cmd = new MySqlCommand(cmdString, conn);
                result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch(MySql.Data.MySqlClient.MySqlException e)
            {
                Console.WriteLine(e.Message);
                Debug.WriteLine(e.Message);
            }
            return result;
        }

        public Boolean findByLogin(string login)
        {
            Boolean result = false;
            string MyConStr = "Server=localhost;Database=" + bd + ";uid=" + user + ";pwd=" + pwd;
            //Etablir la Connexion
            try {
                conn = new MySqlConnection(MyConStr);
                conn.Open();
                if (conn.State == System.Data.ConnectionState.Open)
                {

                }
                MySqlCommand cmd = null;
                string cmdString = "Select * From users where login =" + "'" + login + "'";
                cmd = new MySqlCommand(cmdString, conn);
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    result = true;
                }
                conn.Close();
            }
            catch(MySql.Data.MySqlClient.MySqlException e)
            {
                Console.WriteLine(e.Message);
            }
            return result;
        }
        public Boolean findByLoginAndPassword(string login,string password)
        {
            Boolean result = false;
            string MyConStr = "Server=localhost;Database=" + bd + ";uid=" + user + ";pwd=" + pwd;
            //Etablir la Connexion
            conn = new MySqlConnection(MyConStr);
            conn.Open();
            if (conn.State == System.Data.ConnectionState.Open)
            {

            }
            MySqlCommand cmd = null;
            string cmdString = "Select * From users where login =" + "'" + login + "' AND password='"+password+"'";
            cmd = new MySqlCommand(cmdString, conn);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                result = true;
            }
            conn.Close();
            return result;
        }

        public bool update(User obj)
        {
            throw new NotImplementedException();
        }

        public bool deleteById(int id)
        {
            throw new NotImplementedException();
        }

        public List<User> findAll()
        {
            List<User> liste = new List<User>();
            string MyConStr = "Server=localhost;Database=" + bd + ";uid=" + user + ";pwd=" + pwd;
            //Etablir la Connexion
            conn = new MySqlConnection(MyConStr);
            conn.Open();
            if (conn.State == System.Data.ConnectionState.Open)
            {

            }
            MySqlCommand cmd = null;
            string cmdString = SQL_SELECT_ALL_USER;
            cmd = new MySqlCommand(cmdString, conn);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                User user = new User();
                user.id = dr.GetInt16(0);
                user.nom = dr.GetString(1);
                user.prenom = dr.GetString(2);
                user.login = dr.GetString(3);
                user.profil = dr.GetString(5);
                liste.Add(user);
            }
            conn.Close();
            return liste;
        }

        public User findById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
