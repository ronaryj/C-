﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionCommercial.dao
{
    public interface IDao<T>
    {
        int create(T obj);
        Boolean update(T obj);
        Boolean deleteById(int id);
        List<T> findAll();
        T findById(int id);
    }
}
